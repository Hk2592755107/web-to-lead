<!DOCTYPE html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />

    <!-- Site Title -->
    <title>Hussain - Personal Portfolio</title>

    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="./assets/img/favicon.png" />
    <link
      rel="shortcut icon"
      type="image/png"
      href="./assets/img/favicon.png"
    />

    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/font-awesome-pro.min.css" />
    <link rel="stylesheet" href="assets/css/flaticon_gerold.css" />
    <link rel="stylesheet" href="assets/css/nice-select.css" />
    <link rel="stylesheet" href="assets/css/backToTop.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/odometer-theme-default.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- FancyBox CSS -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css"
    />
  </head>

  <body>
    <!-- Preloader Area Start -->
    <div class="preloader">
      <svg viewBox="0 0 1000 1000" preserveAspectRatio="none">
        <path
          id="preloaderSvg"
          d="M0,1005S175,995,500,995s500,5,500,5V0H0Z"
        ></path>
      </svg>

      <div class="preloader-heading">
        <div class="load-text">
          <span>L</span>
          <span>o</span>
          <span>a</span>
          <span>d</span>
          <span>i</span>
          <span>n</span>
          <span>g</span>
        </div>
      </div>
    </div>
    <!-- Preloader Area End -->

    <!-- start: Back To Top -->
    <div class="progress-wrap" id="scrollUp">
      <svg
        class="progress-circle svg-content"
        width="100%"
        height="100%"
        viewBox="-1 -1 102 102"
      >
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
      </svg>
    </div>
    <!-- end: Back To Top -->

    <!-- HEADER START -->
    <header class="tj-header-area header-absolute">
      <div class="container">
        <div class="row">
          <div class="col-12 d-flex flex-wrap align-items-center">
            <div class="logo-box">
              <a href="index.html">
                <img src="assets/img/logo/logo.png" alt="" />
              </a>
            </div>

            <div class="header-info-list d-none d-md-inline-block">
              <ul class="ul-reset">
                <li>
                  <a href="mailto:hk2592755@gmail.com">hk2592755@gmail.com</a>
                </li>
              </ul>
            </div>

            <div class="header-menu">
              <nav>
                <ul>
                  <li><a href="#services-section">Services</a></li>
                  <li><a href="#works-section">Works</a></li>
                  <li><a href="#resume-section">Resume</a></li>
                  <li><a href="#skills-section">Skills</a></li>
                  <li><a href="#testimonials-section">Testimonials</a></li>
                  <li><a href="#contact-section">Contact</a></li>
                </ul>
              </nav>
            </div>

            <div class="header-button">
              <a href="tel:+923192613543" class="btn tj-btn-primary"
                >Hire me!</a
              >
            </div>

            <div class="menu-bar d-lg-none">
              <button>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
    <header class="tj-header-area header-2 header-sticky sticky-out">
      <div class="container">
        <div class="row">
          <div class="col-12 d-flex flex-wrap align-items-center">
            <div class="logo-box">
              <a href="index.html">
                <img src="assets/img/logo/logo.png" alt="" />
              </a>
            </div>

            <div class="header-info-list d-none d-md-inline-block">
              <ul class="ul-reset">
                <li>
                  <a href="mailto:hk2592755@gmail.com">hk2592755@gmail.com</a>
                </li>
              </ul>
            </div>

            <div class="header-menu">
              <nav>
                <ul>
                  <li><a href="#services-section">Services</a></li>
                  <li><a href="#works-section">Works</a></li>
                  <li><a href="#resume-section">Resume</a></li>
                  <li><a href="#skills-section">Skills</a></li>
                  <li><a href="#testimonials-section">Testimonials</a></li>
                  <li><a href="#contact-section">Contact</a></li>
                </ul>
              </nav>
            </div>

            <div class="header-button">
              <a href="#" class="btn tj-btn-primary">Hire me!</a>
            </div>

            <div class="menu-bar d-lg-none">
              <button>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- HEADER END -->

    <main class="site-content" id="content">
      <!-- HERO SECTION START -->
      <section class="hero-section d-flex align-items-center" id="intro">
        <div class="intro_text">
          <svg viewBox="0 0 1320 300">
            <text x="50%" Y="50%" text-anchor="middle">HI</text>
          </svg>
        </div>
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-6">
              <div class="hero-content-box">
                <span
                  class="hero-sub-title wow fadeInLeft"
                  data-wow-delay="1.1s"
                  >I am Hussain Khan</span
                >
                <h1 class="hero-title wow fadeInLeft" data-wow-delay="1.2s">
                  Full Stack Developer
                </h1>

                <div
                  class="hero-image-box d-md-none text-center wow fadeInRight"
                  data-wow-delay="1.3s"
                >
                  <img src="assets/img/hero/me.png" alt="" />
                </div>

                <p class="lead wow fadeInLeft" data-wow-delay="1.4s">
                  adept at creating dynamic and interactive web applications.
                  crafts seamless user experiences and robust, scalable
                  solutions for diverse client needs.
                </p>
                <div class="button-box d-flex flex-wrap align-items-center">
                  <a
                    href="assets/img/screenshot.pdf"
                    download
                    class="btn tj-btn-secondary wow fadeInLeft"
                    data-wow-delay="1.5s"
                    >Download CV</a
                  >
                  <ul
                    class="ul-reset social-icons wow fadeInLeft"
                    data-wow-delay="1.6s"
                  >
                    <li>
                      <a href="#"><i class="fa-brands fa-twitter"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa-light fa-basketball"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa-brands fa-github"></i></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-6 d-none d-md-block">
              <div
                class="hero-image-box text-center wow fadeInRight"
                data-wow-delay="1.5s"
              >
                <img src="assets/img/hero/me.png" alt="" />
              </div>
            </div>
          </div>

          <div class="funfact-area">
            <div class="row">
              <div class="col-6 col-lg-3">
                <div
                  class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center"
                >
                  <div class="number">
                    <span class="odometer" data-count="2">0</span>
                  </div>
                  <div class="text">Years of <br />Experience</div>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div
                  class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center"
                >
                  <div class="number">
                    <span class="odometer" data-count="30">0</span>+
                  </div>
                  <div class="text">Project <br />Completed</div>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div
                  class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center"
                >
                  <div class="number">
                    <span class="odometer" data-count="10">0</span>+
                  </div>
                  <div class="text">Happy <br />Clients</div>
                </div>
              </div>
              <div class="col-6 col-lg-3">
                <div
                  class="funfact-item d-flex flex-column flex-sm-row flex-wrap align-items-center"
                >
                  <div class="number">
                    <span class="odometer" data-count="80"></span>%
                  </div>
                  <div class="text">Client<br />Satisfications</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- HERO SECTION END -->

      <!-- SERVICES SECTION START -->
      <section class="services-section" id="services-section">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="section-header text-center">
                <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">
                  My Quality Services
                </h2>
                <p class="wow fadeInUp" data-wow-delay=".4s">
                  We delivers high-quality services tailored to meet clients'
                  needs. With a strong focus on both frontend and backend
                  development, We ensures the creation of robust, scalable, and
                  user-friendly web applications.
                </p>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-12">
              <div class="services-widget position-relative">
                <div
                  class="service-item current d-flex flex-wrap align-items-center wow fadeInUp"
                  data-wow-delay=".5s"
                >
                  <div class="left-box d-flex flex-wrap align-items-center">
                    <span class="number">01</span>
                    <h3 class="service-title">Frontend</h3>
                  </div>
                  <div class="right-box">
                    <p>
                      "I specialize in front-end development using HTML, CSS,
                      and JavaScript. With experience across multiple brands,
                      I've worked extensively on projects related to ebooks and
                      academic content.
                    </p>
                  </div>
                  <i class="flaticon-up-right-arrow"></i>
                  <button
                    data-mfp-src="#service-wrapper"
                    class="service-link"
                  ></button>
                </div>
                <div
                  class="service-item d-flex flex-wrap align-items-center wow fadeInUp"
                  data-wow-delay=".6s"
                >
                  <div class="left-box d-flex flex-wrap align-items-center">
                    <span class="number">02</span>
                    <h3 class="service-title">Backend</h3>
                  </div>
                  <div class="right-box">
                    <p>
                      I bring robust backend development skills using PHP and
                      Laravel. Leveraging these tools, I create efficient and
                      scalable server-side solutions that complement the front
                      end.
                    </p>
                  </div>
                  <i class="flaticon-up-right-arrow"></i>
                  <button
                    data-mfp-src="#service-wrapper"
                    class="service-link"
                  ></button>
                </div>

                <div class="active-bg wow fadeInUp" data-wow-delay=".5s"></div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- SERVICES SECTION END -->

      <!-- start: Service Popup -->
      <div
        id="service-wrapper"
        class="popup_content_area zoom-anim-dialog mfp-hide"
      >
        <div class="popup_modal_img">
          <img src="./assets/img/services/modal-img.jpg" alt="" />
        </div>

        <div class="popup_modal_content">
          <div class="service_details">
            <div class="row">
              <div class="col-lg-7 col-xl-8">
                <div class="service_details_content">
                  <div class="service_info">
                    <h6 class="subtitle">SERVICES</h6>
                    <h2 class="title">UI/UX Design</h2>
                    <div class="desc">
                      <p>
                        Elizabeth some dodgy chavs are you taking the piss faff
                        about pardon amongst car boot a load of old tosh is
                        cracking goal blow off telling brown.
                      </p>

                      <p>
                        Brolly show off show off pick your nose and blow off
                        well A bit of how’s your father tomfoolery blimey, me
                        old mucker starkers Queen’s English dropped a clanger
                        bite your arm spiffing good time burke Why chancer.
                        Hotpot bum bag cracking goal young delinquent naff
                        bugger cup of chars bender loo it’s all gone to pot the
                        nancy cheeky.
                      </p>

                      <p>
                        At public school cras bog some dodgy chav Richard Why
                        argy bargy vagabon William bender matie boy, off his nut
                        chancer Jeffrey up the kyver say mufty you mug ummm
                        telling pear shaped Oxford owt to do with me do one so
                        said are you taking his.
                      </p>
                    </div>

                    <h3 class="title">Services Process</h3>
                    <div class="desc">
                      <p>
                        Elizabeth some dodgy chavs are you taking the piss faff
                        about pardon amongst car boot a load of old tosh is
                        cracking goal blow off telling brown.
                      </p>
                    </div>
                    <ul>
                      <li>Reinvent Your Business to Better</li>
                      <li>Pioneering the Internet's First</li>
                      <li>Pioneering the Design World's First</li>
                      <li>Pioneering the Design World's First</li>
                      <li>Pioneering the Design World's First</li>
                      <li>Pioneering the Design World's First</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-lg-5 col-xl-4">
                <div class="tj_main_sidebar">
                  <div class="sidebar_widget services_list">
                    <div class="widget_title">
                      <h3 class="title">All Services</h3>
                    </div>
                    <ul>
                      <li class="active">
                        <button>
                          <i class="flaticon-design"></i>
                          Branding Design
                        </button>
                      </li>
                      <li>
                        <button>
                          <i class="flaticon-3d-movie"></i>
                          3D Animation
                        </button>
                      </li>
                      <li>
                        <button>
                          <i class="flaticon-ux-design"></i>
                          UI/UX Design
                        </button>
                      </li>
                      <li>
                        <button>
                          <i class="flaticon-web-design"></i>
                          Web Design
                        </button>
                      </li>
                      <li>
                        <button>
                          <i class="flaticon-ui-design"></i>
                          App Design
                        </button>
                      </li>
                    </ul>
                  </div>

                  <div class="sidebar_widget contact_form">
                    <div class="widget_title">
                      <h3 class="title">Get in Touch</h3>
                    </div>

                    <form action="index.html">
                      <div class="form_group">
                        <input
                          type="text"
                          name="name"
                          id="name"
                          placeholder="Name"
                          autocomplete="off"
                        />
                      </div>
                      <div class="form_group">
                        <input
                          type="email"
                          name="semail"
                          id="semail"
                          placeholder="Email"
                          autocomplete="off"
                        />
                      </div>
                      <div class="form_group">
                        <textarea
                          name="smessage"
                          id="smessage"
                          placeholder="Your message"
                          autocomplete="off"
                        ></textarea>
                      </div>
                      <div class="form_btn">
                        <button class="btn tj-btn-primary" type="submit">
                          Send Message
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end: Service Popup -->

      <!-- PORTFOLIO SECTION START -->
      <section class="portfolio-section" id="works-section">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="section-header text-center">
                <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">
                  My Recent Works
                </h2>
                <p class="wow fadeInUp" data-wow-delay=".4s">
                  Our recent works showcase a diverse range of projects,
                  including dynamic web applications, visually appealing
                  designs, and innovative solutions tailored to client needs.
                </p>
              </div>
            </div>
          </div>
          <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
              <button
                class="nav-link active"
                id="pills-backend-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-backend"
                type="button"
                role="tab"
                aria-controls="pills-backend"
                aria-selected="true"
              >
                Backend
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="pills-ebook-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-ebook"
                type="button"
                role="tab"
                aria-controls="pills-design"
                aria-selected="false"
              >
                Ebook
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="pills-academic-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-academic"
                type="button"
                role="tab"
                aria-controls="pills-academic"
                aria-selected="false"
              >
                Academic
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button
                class="nav-link"
                id="pills-brand-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-brand"
                type="button"
                role="tab"
                aria-controls="pills-brand"
                aria-selected="false"
              >
                Brands
              </button>
            </li>
          </ul>
          <div class="tab-content" id="pills-tabContent">
            <div
              class="tab-pane fade show active"
              id="pills-backend"
              role="tabpanel"
              aria-labelledby="pills-backend-tab"
            >
              <div class="portfolio-box wow fadeInUp" data-wow-delay=".6s">
                <div class="portfolio-sizer"></div>
                <div class="gutter-sizer"></div>
                <div class="portfolio-item backend">
                  <div class="image-box">
                    <img src="assets/img/portfolio/2.jpg" alt="" />
                  </div>
                  <div class="content-box">
                    <h3 class="portfolio-title">Portofino</h3>
                    <p>
                      Portfino develop using PHP Laravel Framework and same
                      Design on Wordpress on Client Requirment
                    </p>
                    <i class="flaticon-up-right-arrow"></i>
                    <button
                      data-mfp-src="#portfolio-wrapper"
                      class="portfolio-link modal-popup-portfino"
                    ></button>
                  </div>
                </div>
                <div class="portfolio-item backend">
                  <div class="image-box">
                    <img src="assets/img/portfolio/3.jpg" alt="" />
                  </div>
                  <div class="content-box">
                    <h3 class="portfolio-title">Boleto</h3>
                    <p>Boleto developed using PHP Laravel Framework</p>
                    <i class="flaticon-up-right-arrow"></i>
                    <button
                      data-mfp-src="#portfolio-wrapper-movie"
                      class="portfolio-link modal-popup-movie"
                    ></button>
                  </div>
                </div>
                <div class="portfolio-item backend">
                  <div class="image-box">
                    <img src="assets/img/portfolio/4.jpg" alt="" />
                  </div>
                  <div class="content-box">
                    <h3 class="portfolio-title">FoodBazaar</h3>
                    <p>FoodBazaar develop using Python Framework Django</p>
                    <i class="flaticon-up-right-arrow"></i>
                    <button
                      data-mfp-src="#portfolio-wrapper-foodbazaar"
                      class="portfolio-link modal-popup-foodbazaar"
                    ></button>
                  </div>
                </div>
                <div class="portfolio-item backend">
                  <div class="image-box">
                    <img src="assets/img/portfolio/law2.jpg" alt="" />
                  </div>
                  <div class="content-box">
                    <h3 class="portfolio-title">Law Firm Agency</h3>
                    <p>Law Firm Agency developed using PHP Laravel Framework</p>
                    <i class="flaticon-up-right-arrow"></i>
                    <button
                      data-mfp-src="#portfolio-wrapper-jewellery"
                      class="portfolio-link modal-popup-jewellery"
                    ></button>
                  </div>
                </div>
                <div class="portfolio-item backend">
                  <div class="image-box">
                    <img src="assets/img/portfolio/5.jpg" alt="" />
                  </div>
                  <div class="content-box">
                    <h3 class="portfolio-title">Elibrary</h3>
                    <p>Elibrary develop using Python Framework Django</p>
                    <i class="flaticon-up-right-arrow"></i>
                    <button
                      data-mfp-src="#portfolio-wrapper-library"
                      class="portfolio-link modal-popup-library"
                    ></button>
                  </div>
                </div>
                <div class="portfolio-item">
                  <div class="image-box">
                    <img src="assets/img/portfolio/p.png" alt="" />
                  </div>
                  <div class="content-box">
                    <h3 class="portfolio-title">Perfex CRM</h3>
                    <p>
                      I am actively working on customizing Perfex CRM, creating
                      new modules and tailoring its functionalities to meet
                      specific business needs.
                    </p>
                    <i class="flaticon-up-right-arrow"></i>
                    <button
                      data-mfp-src="#portfolio-wrapper-radio"
                      class="portfolio-link modal-popup-radio"
                    ></button>
                  </div>
                </div>
              </div>
            </div>

            <div
              class="tab-pane fade"
              id="pills-ebook"
              role="tabpanel"
              aria-labelledby="pills-ebook-tab"
            >
              <section class="custm">
                <div class="container">
                  <div class="row justify-content-center">
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/ebook/1.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/1.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/1.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/ebook/2.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/2.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/2.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/ebook/3.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/3.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/3.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/ebook/4.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/4.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/4.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/ebook/5.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/5.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/5.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/ebook/6.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/6.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/6.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/ebook/7.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/7.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/7.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/ebook/8.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/8.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/8.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/ebook/9.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/ebook/9.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/ebook/9.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </section>
            </div>
            <div
              class="tab-pane fade"
              id="pills-academic"
              role="tabpanel"
              aria-labelledby="pills-academic-tab"
            >
              <section class="custm">
                <div class="container">
                  <div class="row justify-content-center">
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/education/1.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/1.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/1.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/education/2.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/2.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/2.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/education/3.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/3.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/3.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/education/4.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/4.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/4.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/education/5.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/5.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/5.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/education/6.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/6.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/6.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/education/7.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/7.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/7.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/education/8.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/8.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/8.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/education/9.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/education/9.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/education/9.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            <div
              class="tab-pane fade"
              id="pills-brand"
              role="tabpanel"
              aria-labelledby="pills-brand-tab"
            >
              <section class="custm">
                <div class="container">
                  <div class="row justify-content-center">
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/brands/1.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/brands/1.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/brands/1.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/brands/2.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/brands/2.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/brands/2.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/brands/3.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/brands/3.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/brands/3.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-6">
                      <a
                        href="assets/img/portfolio/brands/4.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/brands/4.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/brands/4.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/brands/5.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/brands/5.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/brands/5.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                    <div class="col-12 col-md-3">
                      <a
                        href="assets/img/portfolio/brands/6.png"
                        class="portfolio__img"
                        data-fancybox="gallery"
                      >
                        <img
                          data-src="assets/img/portfolio/brands/6.png"
                          alt=""
                          class="imgFluid lazy loaded"
                          src="assets/img/portfolio/brands/6.png"
                          data-was-processed="true"
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </section>

      <!-- PORTFOLIO SECTION END -->

      <!-- start: Portfolio Popup Portfino -->
      <div
        id="portfolio-wrapper"
        class="popup_content_area zoom-anim-dialog mfp-hide"
      >
        <div class="popup_modal_img">
          <img src="./assets/img/portfolio/modal-img.png" alt="" />
        </div>

        <div class="popup_modal_content">
          <div class="portfolio_info">
            <div class="portfolio_info_text">
              <h2 class="title">Portofino</h2>
              <div class="desc">
                <p>
                  Portofino Car Rental company is an independent rent a car
                  facility in Dubai. We offer luxury cars in the vicinity to
                  those who want to visit the city in style.
                </p>
              </div>
              <a href="https://portofinorentacar.ae/" class="btn tj-btn-primary"
                >live preview <i class="fal fa-arrow-right"></i
              ></a>
            </div>
          </div>

          <div class="portfolio_gallery owl-carousel">
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/portfino1.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/portfino2.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/portfino3.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/portfino4.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/portfino5.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/portfino6.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/portfino7.jpg" alt="" />
            </div>
          </div>

          <div class="portfolio_description">
            <h2 class="title">Project Description</h2>
            <div class="desc">
              <p>
                Portfino is an online platform designed to provide an
                exceptional luxury car rental experience in Dubai. Catering to
                discerning customers seeking style, comfort, and prestige,
                Portfino offers a curated selection of premium vehicles and
                personalized service.
              </p>

              <p>
                Explore a diverse range of luxury cars including sedans, sports
                cars, SUVs, and exotic models from top brands like Ferrari,
                Lamborghini, Rolls Royce, and more.
              </p>
            </div>
          </div>

          <div class="portfolio_story_approach">
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">The story</h4>
              </div>
              <div class="story_content">
                <p>
                  All of the luxury cars and super brands are right here:
                  Rolls-Royce, Bentley, Lamborghini, Tesla, McLaren, Ferrari,
                  Porsche, Mercedes-Benz, BMW, Cadillac, GMC, Land Rover, Audi,
                  Ford, Nissan and more.
                </p>
              </div>
            </div>
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">Technologies Used</h4>
              </div>
              <div class="story_content">
                <li>
                  <strong>PHP Laravel:</strong> MVC framework for backend
                  development
                </li>
                <li>
                  <strong>HTML/CSS/JavaScript:</strong> Frontend development for
                  user interface and interactivity
                </li>
                <li>
                  <strong>MySQL:</strong> Relational database management system
                  for data storage
                </li>
              </div>
            </div>
            <div class="portfolio_approach">
              <div class="approach_title">
                <h4 class="title">OUR APPROACH</h4>
              </div>
              <div class="approach_content">
                <p>
                  Conduct in-depth market research to understand the luxury car
                  rental industry in Dubai. Analyze competitors, customer
                  preferences, and emerging trends to identify opportunities and
                  challenges.Clearly define the objectives and goals of the
                  project, including target audience demographics, revenue
                  targets, and desired user experience.Develop a comprehensive
                  project plan and strategy, outlining the scope.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_navigation">
            <div class="navigation_item prev-project">
              <a href="#" class="project">
                <i class="fal fa-arrow-left"></i>
                <div class="nav_project">
                  <div class="label">Previous Project</div>
                  <h3 class="title"></h3>
                </div>
              </a>
            </div>

            <div class="navigation_item next-project">
              <a href="#" class="project">
                <div class="nav_project">
                  <div class="label">Next Project</div>
                  <h3 class="title"></h3>
                </div>
                <i class="fal fa-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- end: Portfolio Popup -->
      <!-- start: Portfolio Popup movie -->
      <div
        id="portfolio-wrapper-movie"
        class="popup_content_area zoom-anim-dialog mfp-hide"
      >
        <div class="popup_modal_img">
          <img src="./assets/img/portfolio-gallery/movie1.jpg" alt="" />
        </div>

        <div class="popup_modal_content">
          <div class="portfolio_info">
            <div class="portfolio_info_text">
              <h2 class="title">Boleto</h2>
              <div class="desc">
                <p>
                  Boleto is an online movie ticket booking system developed
                  using the PHP Laravel framework. Laravel is a popular PHP
                  framework known for its elegant syntax, robust features, and
                  developer-friendly environment.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_gallery owl-carousel">
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie2.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie3.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie4.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie5.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie6.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie7.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie8.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie9.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/movie10.jpg" alt="" />
            </div>
          </div>

          <div class="portfolio_description">
            <h2 class="title">Project Description</h2>
            <div class="desc">
              <p>
                Developing a movie ticket booking system with Laravel can
                provide benefits such as rapid development, scalability, and
                maintainability.
              </p>

              <p>
                Boleto is an online movie ticket booking system developed using
                PHP Laravel, a powerful and popular MVC framework for web
                application development. The system is designed to provide users
                with a convenient platform to browse movie listings, select
                showtimes, book tickets,watch trailers and download your
                tickets.
              </p>
            </div>
          </div>

          <div class="portfolio_story_approach">
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">The story</h4>
              </div>
              <div class="story_content">
                <p>
                  Boleto aims to revolutionize the moviegoing experience, making
                  it easier and more convenient for users to plan their cinema
                  outings and enjoy their favorite films with hassle-free ticket
                  booking.
                </p>
              </div>
            </div>
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">Technologies Used</h4>
              </div>
              <div class="story_content">
                <li>
                  <strong>PHP Laravel:</strong> MVC framework for backend
                  development
                </li>
                <li>
                  <strong>HTML/CSS/JavaScript:</strong> Frontend development for
                  user interface and interactivity
                </li>
                <li>
                  <strong>MySQL:</strong> Relational database management system
                  for data storage
                </li>
              </div>
            </div>
            <div class="portfolio_approach">
              <div class="approach_title">
                <h4 class="title">OUR APPROACH</h4>
              </div>
              <div class="approach_content">
                <p>
                  Provide a user-friendly and intuitive platform for booking
                  movie tickets online. Ensure seamless functionality across
                  desktop and mobile devices. Implement robust security measures
                  to protect user data, transactions, and ticket validity. Offer
                  efficient ticket booking and payment processing workflows to
                  enhance user experience. Collaborate with theater owners to
                  onboard their venues and listings onto the platform.
                  Continuously update and improve the system based on user
                  feedback and market trends to stay competitive in the online
                  ticketing industry.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_navigation">
            <div class="navigation_item prev-project">
              <a href="#" class="project">
                <i class="fal fa-arrow-left"></i>
                <div class="nav_project">
                  <div class="label">Previous Project</div>
                  <h3 class="title"></h3>
                </div>
              </a>
            </div>

            <div class="navigation_item next-project">
              <a href="#" class="project">
                <div class="nav_project">
                  <div class="label">Next Project</div>
                  <h3 class="title"></h3>
                </div>
                <i class="fal fa-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- end: Portfolio movie -->

      <!-- start: Portfolio Popup Foodbazaar -->
      <div
        id="portfolio-wrapper-foodbazaar"
        class="popup_content_area zoom-anim-dialog mfp-hide"
      >
        <div class="popup_modal_img">
          <img src="./assets/img/portfolio-gallery/food1.jpg" alt="" />
        </div>

        <div class="popup_modal_content">
          <div class="portfolio_info">
            <div class="portfolio_info_text">
              <h2 class="title">FoodBazaar</h2>
              <div class="desc">
                <p>
                  Food Bazaar is an online food ordering system that aims to
                  provide users with a seamless and convenient platform to order
                  food from various restaurants or food vendors. The system will
                  be developed using Django, a high-level Python web framework,
                  ensuring robustness, scalability, and ease of maintenance.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_gallery owl-carousel">
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food2.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food3.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food4.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food5.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food6.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food7.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food8.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food9.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/food10.jpg" alt="" />
            </div>
          </div>

          <div class="portfolio_description">
            <h2 class="title">Project Description</h2>
            <div class="desc">
              <p>
                The platform will feature a comprehensive list of restaurants or
                food vendors, categorized by cuisine type, location, and other
                relevant filters. Users can browse through the menus of various
                restaurants, view item details, and add desired items to their
                cart.
              </p>

              <p>
                Users can create accounts, log in securely, and manage their
                profiles. Social media login options may also be provided for
                added convenience. An administrative dashboard will be provided
                for restaurant owners or administrators to manage menu items,
                update prices, monitor orders, and view analytics. Users can
                leave reviews and ratings for restaurants and individual dishes
              </p>
            </div>
          </div>

          <div class="portfolio_story_approach">
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">The story</h4>
              </div>
              <div class="story_content">
                <p>
                  Food Bazaar aims to revolutionize the online food ordering
                  experience, making it easier and more enjoyable for users to
                  explore diverse cuisines and satisfy their cravings with just
                  a few clicks.
                </p>
              </div>
            </div>
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">Technologies Used</h4>
              </div>
              <div class="story_content">
                <li>
                  <strong>Django:</strong>Python web framework for backend
                  development
                </li>
                <li>
                  <strong>HTML/CSS/JavaScript:</strong> Frontend development for
                  user interface and interactivity
                </li>
                <li>
                  <strong>MySQL:</strong> Relational database management system
                  for data storage
                </li>
              </div>
            </div>
            <div class="portfolio_approach">
              <div class="approach_title">
                <h4 class="title">OUR APPROACH</h4>
              </div>
              <div class="approach_content">
                <p>
                  Create a user-friendly and intuitive platform for ordering
                  food online. Ensure seamless functionality across desktop and
                  mobile devices. Implement robust security measures to protect
                  user data and transactions. Provide an efficient and scalable
                  architecture to handle increasing user traffic and restaurant
                  listings. Offer excellent customer support and continuously
                  improve the platform based on user feedback and analytics.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_navigation">
            <div class="navigation_item prev-project">
              <a href="#" class="project">
                <i class="fal fa-arrow-left"></i>
                <div class="nav_project">
                  <div class="label">Previous Project</div>
                  <h3 class="title"></h3>
                </div>
              </a>
            </div>

            <div class="navigation_item next-project">
              <a href="#" class="project">
                <div class="nav_project">
                  <div class="label">Next Project</div>
                  <h3 class="title"></h3>
                </div>
                <i class="fal fa-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- end: Portfolio Foodbazaar -->
      <!-- start: Portfolio Popup Ai Radio -->
      <div
        id="portfolio-wrapper-radio"
        class="popup_content_area zoom-anim-dialog mfp-hide"
      >
        <div class="popup_modal_img">
          <img src="./assets/img/portfolio-gallery/p2.png" alt="" />
        </div>

        <div class="popup_modal_content">
          <div class="portfolio_info">
            <div class="portfolio_info_text">
              <h2 class="title">Perfex Crm</h2>
              <div class="desc">
                <p>
                  I am actively working on customizing Perfex CRM, creating new
                  modules and tailoring its functionalities to meet specific
                  client needs. My experience in enhancing CRM capabilities
                  ensures a tailored, effective solution that aligns with unique
                  business requirements.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_gallery owl-carousel">
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/p3.png" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/p4.png" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/p5.png" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/p6.png" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/p7.png" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/p8.png" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/p9.png" alt="" />
            </div>
          </div>

          <div class="portfolio_description">
            <h2 class="title">Project Description</h2>
            <div class="desc">
              <p>
                Perfex CRM is an open-source Customer Relationship Management software designed primarily for small and medium-sized businesses. It provides tools to manage client relationships, projects, and finances.
              </p>

              <p>
                With features like task management, invoicing, project tracking, and customer support, it’s widely used in sectors that benefit from detailed project management and efficient client communication.
                Perfex CRM is built using PHP and is powered by the CodeIgniter framework, which makes it flexible and relatively easy to customize and extend.
              </p>
            </div>
          </div>

          <div class="portfolio_story_approach">
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">The story</h4>
              </div>
              <div class="story_content">
                <p>
                  Maintain detailed client profiles, communication history, and support tickets.Its modular structure allows adding and modifying modules to fit specific requirements.

                </p>
              </div>
            </div>
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">Technologies Used</h4>
              </div>
              <div class="story_content">
                <li>
                  <strong>PHP:</strong>The Crm is developed using the
                  CodeIgniter framework.
                </li>
                <li>
                  <strong>HTML/CSS/JavaScript:</strong>Frontend development for user interface and interactivity
                </li>
                <li>
                  <strong>MySQL:</strong>Relational database management system for data storage
                </li>
              </div>
            </div>
            <div class="portfolio_approach">
              <div class="approach_title">
                <h4 class="title">OUR APPROACH</h4>
              </div>
              <div class="approach_content">
                <p>
                  Our approach to customizing Perfex CRM focuses on collaboration, flexibility, and a deep understanding of client needs. By leveraging advanced technologies and methodologies, we aim to deliver a robust CRM solution that empowers
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_navigation">
            <div class="navigation_item prev-project">
              <a href="#" class="project">
                <i class="fal fa-arrow-left"></i>
                <div class="nav_project">
                  <div class="label">Previous Project</div>
                  <h3 class="title"></h3>
                </div>
              </a>
            </div>

            <div class="navigation_item next-project">
              <a href="#" class="project">
                <div class="nav_project">
                  <div class="label">Next Project</div>
                  <h3 class="title"></h3>
                </div>
                <i class="fal fa-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- end: Portfolio Ai Radio -->

      <!-- start: Portfolio Popup Law Firm Agency -->
      <div
        id="portfolio-wrapper-jewellery"
        class="popup_content_area zoom-anim-dialog mfp-hide"
      >
        <div class="popup_modal_img">
          <img src="./assets/img/portfolio-gallery/law1.jpg" alt="" />
        </div>

        <div class="popup_modal_content">
          <div class="portfolio_info">
            <div class="portfolio_info_text">
              <h2 class="title">Law Firm Agency</h2>
              <div class="desc">
                <p>
                  The Lawyer Appointments website is a modern and user-friendly
                  platform designed to facilitate the booking of appointments
                  with lawyers.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_gallery owl-carousel">
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law3.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law4.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law5.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law6.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law7.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law8.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law9.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law10.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law11.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/law12.jpg" alt="" />
            </div>
          </div>

          <div class="portfolio_description">
            <h2 class="title">Project Description</h2>
            <div class="desc">
              <p>
                Built using the PHP Laravel framework, this website offers a
                seamless experience for both clients seeking legal assistance
                and lawyers managing their schedules. Clients and lawyers can
                register and log in securely to access the platform's features.
              </p>

              <p>
                Clients can browse through the list of available lawyers, view
                their profiles, and schedule appointments based on their
                availability. Lawyers can create and manage their profiles.The
                website is designed to be fully responsive, ensuring a seamless
                experience across various devices, including desktops, tablets,
                and smartphones.
              </p>
            </div>
          </div>

          <div class="portfolio_story_approach">
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">The story</h4>
              </div>
              <div class="story_content">
                <p>
                  The Lawyer Appointments website powered by PHP Laravel offers
                  a sophisticated yet straightforward solution for connecting
                  clients with legal professionals.
                </p>
              </div>
            </div>
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">Technologies Used</h4>
              </div>
              <div class="story_content">
                <li>
                  <strong>PHP Laravel:</strong> MVC framework for backend
                  development
                </li>
                <li>
                  <strong>HTML/CSS/JavaScript:</strong> Frontend development for
                  user interface and interactivity
                </li>
                <li>
                  <strong>MySQL:</strong> Relational database management system
                  for data storage
                </li>
              </div>
            </div>
            <div class="portfolio_approach">
              <div class="approach_title">
                <h4 class="title">OUR APPROACH</h4>
              </div>
              <div class="approach_content">
                <p>
                  Convenient and efficient appointment scheduling for clients
                  and lawyers. Enhanced visibility and accessibility for
                  lawyers, leading to increased client engagement and business
                  opportunities. Improved user experience through intuitive
                  design and user-friendly features. Secure and reliable
                  platform for handling sensitive legal matters.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_navigation">
            <div class="navigation_item prev-project">
              <a href="#" class="project">
                <i class="fal fa-arrow-left"></i>
                <div class="nav_project">
                  <div class="label">Previous Project</div>
                  <h3 class="title"></h3>
                </div>
              </a>
            </div>

            <div class="navigation_item next-project">
              <a href="#" class="project">
                <div class="nav_project">
                  <div class="label">Next Project</div>
                  <h3 class="title"></h3>
                </div>
                <i class="fal fa-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- end: Portfolio Law Firm Agency -->
      <!-- start: Portfolio Popup library -->
      <div
        id="portfolio-wrapper-library"
        class="popup_content_area zoom-anim-dialog mfp-hide"
      >
        <div class="popup_modal_img">
          <img src="./assets/img/portfolio-gallery/e2.jpg" alt="" />
        </div>

        <div class="popup_modal_content">
          <div class="portfolio_info">
            <div class="portfolio_info_text">
              <h2 class="title">Elibrary</h2>
              <div class="desc">
                <p>
                  eLibrary is an online platform designed to provide users with
                  access to a vast collection of books across various genres,
                  authors, and topics. Built using the Django framework in
                  Python
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_gallery owl-carousel">
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e3.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e4.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e5.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e6.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e7.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e8.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e9.jpg" alt="" />
            </div>
            <div class="gallery_item">
              <img src="./assets/img/portfolio-gallery/e10.jpg" alt="" />
            </div>
          </div>

          <div class="portfolio_description">
            <h2 class="title">Project Description</h2>
            <div class="desc">
              <p>
                eLibrary offers a user-friendly interface for discovering,
                reading, and interacting with digital books.Users can sign up,
                log in, and manage their accounts securely. Browse through an
                extensive collection of books categorized by genre, author, and
                popularity.View detailed information about each book, including
                title, author, description, and user ratings.
              </p>

              <p>
                Administrators have access to a comprehensive admin panel for
                managing books, users, and site content. Add new books, update
                existing entries, and moderate user-generated content to
                maintain quality standards. eLibrary is optimized for seamless
                browsing on desktops, laptops, tablets, and smartphones.
              </p>
            </div>
          </div>

          <div class="portfolio_story_approach">
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">The story</h4>
              </div>
              <div class="story_content">
                <p>
                  eLibrary aims to revolutionize the way users discover, access,
                  and engage with digital books online.
                </p>
              </div>
            </div>
            <div class="portfolio_story">
              <div class="story_title">
                <h4 class="title">Technologies Used</h4>
              </div>
              <div class="story_content">
                <li>
                  <strong>Django:</strong>Python web framework for backend
                  development
                </li>
                <li>
                  <strong>HTML/CSS/JavaScript:</strong> Frontend development for
                  user interface and interactivity
                </li>
                <li>
                  <strong>MySQL:</strong> Relational database management system
                  for data storage
                </li>
              </div>
            </div>
            <div class="portfolio_approach">
              <div class="approach_title">
                <h4 class="title">OUR APPROACH</h4>
              </div>
              <div class="approach_content">
                <p>
                  Whether you're a passionate reader seeking your next literary
                  adventure or an author looking to share your work with a
                  global audience, eLibrary offers a dynamic platform for
                  exploration, interaction, and community building.
                </p>
              </div>
            </div>
          </div>

          <div class="portfolio_navigation">
            <div class="navigation_item prev-project">
              <a href="#" class="project">
                <i class="fal fa-arrow-left"></i>
                <div class="nav_project">
                  <div class="label">Previous Project</div>
                  <h3 class="title"></h3>
                </div>
              </a>
            </div>

            <div class="navigation_item next-project">
              <a href="#" class="project">
                <div class="nav_project">
                  <div class="label">Next Project</div>
                  <h3 class="title"></h3>
                </div>
                <i class="fal fa-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- end: Portfolio library -->

      <!-- RESUME SECTION START -->
      <section class="resume-section" id="resume-section">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="section-header wow fadeInUp" data-wow-delay=".3s">
                <h2 class="section-title">My Experience</h2>
              </div>

              <div class="resume-widget">
                <div class="resume-item wow fadeInLeft" data-wow-delay=".4s">
                  <div class="time">2024 - Present</div>
                  <h3 class="resume-title">Full Stack Web Developer</h3>
                  <div class="institute">Aim Digital</div>
                </div>
                <div class="resume-item wow fadeInLeft" data-wow-delay=".5s">
                  <div class="time">2023</div>
                  <h3 class="resume-title">Frontend Developer</h3>
                  <div class="institute">Aim Digital</div>
                </div>
                <div class="resume-item wow fadeInLeft" data-wow-delay=".6s">
                  <div class="time">2022</div>
                  <h3 class="resume-title">Internship</h3>
                  <div class="institute">Grow Digital Care</div>
                </div>
              </div>
            </div>

            <div class="col-md-6">
              <div class="section-header wow fadeInUp" data-wow-delay=".4s">
                <h2 class="section-title">My Education</h2>
              </div>

              <div class="resume-widget">
                <div class="resume-item wow fadeInRight" data-wow-delay=".5s">
                  <div class="time">2015 - 2016</div>
                  <h3 class="resume-title">Matric</h3>
                  <div class="institute">New Roomi School</div>
                </div>
                <div class="resume-item wow fadeInRight" data-wow-delay=".6s">
                  <div class="time">2020 - 2022</div>
                  <h3 class="resume-title">Inter</h3>
                  <div class="institute">Islamia College</div>
                </div>
                <div class="resume-item wow fadeInRight" data-wow-delay=".7s">
                  <div class="time">2019 - 2023</div>
                  <h3 class="resume-title">Software Engineer</h3>
                  <div class="institute">Aptech Computer Education</div>
                </div>
                <div class="resume-item wow fadeInRight" data-wow-delay=".8s">
                  <div class="time">2023</div>
                  <h3 class="resume-title">DevOps</h3>
                  <div class="institute">PIAIC</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- RESUME SECTION END -->

      <!-- SKILLS SECTION START -->
      <section class="skills-section" id="skills-section">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="section-header text-center">
                <h2 class="section-title wow fadeInUp" data-wow-delay=".3s">
                  My Skills
                </h2>
                <p class="wow fadeInUp" data-wow-delay=".4s">
                  We put your ideas and thus your wishes in the form of a unique
                  web project that inspires you and you customers.
                </p>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-12">
              <div
                class="skills-widget d-flex flex-wrap justify-content-center align-items-center"
              >
                <div class="skill-item wow fadeInUp" data-wow-delay=".3s">
                  <div class="skill-inner">
                    <div class="icon-box">
                      <img src="assets/img/html.png" alt="" />
                    </div>
                    <div class="number">92%</div>
                  </div>
                  <p>Html</p>
                </div>
                <div class="skill-item wow fadeInUp" data-wow-delay=".4s">
                  <div class="skill-inner">
                    <div class="icon-box">
                      <img src="assets/img/css.svg" alt="" />
                    </div>
                    <div class="number">80%</div>
                  </div>
                  <p>Css</p>
                </div>
                <div class="skill-item wow fadeInUp" data-wow-delay=".8s">
                  <div class="skill-inner">
                    <div class="icon-box">
                      <img src="assets/img/icons/js.svg" alt="" />
                    </div>
                    <div class="number">70%</div>
                  </div>
                  <p>JavaScript</p>
                </div>
                <div class="skill-item wow fadeInUp" data-wow-delay=".5s">
                  <div class="skill-inner">
                    <div class="icon-box">
                      <img src="assets/img/bootstrap.png" alt="" />
                    </div>
                    <div class="number">90%</div>
                  </div>
                  <p>Bootstrap</p>
                </div>
                <div class="skill-item wow fadeInUp" data-wow-delay=".6s">
                  <div class="skill-inner">
                    <div class="icon-box">
                      <img src="assets/img/php.png" alt="" />
                    </div>
                    <div class="number">70%</div>
                  </div>
                  <p>Php</p>
                </div>
                <div class="skill-item wow fadeInUp" data-wow-delay=".7s">
                  <div class="skill-inner">
                    <div class="icon-box">
                      <img src="assets/img/Laravel.svg.png" alt="" />
                    </div>
                    <div class="number">85%</div>
                  </div>
                  <p>Laravel</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- SKILLS SECTION END -->

      <!-- TESTIMONIAL SECTION START -->
      <section class="testimonial-section" id="testimonials-section">
        <div class="container">
          <div class="row">
            <div class="col-lg-5">
              <div class="section-header">
                <h2 class="section-title wow fadeInLeft" data-wow-delay=".3s">
                  My Client's Stories
                </h2>
                <p class="wow fadeInLeft" data-wow-delay=".4s">
                  Empowering people in new a digital journey with my super
                  services
                </p>
              </div>
            </div>

            <div class="col-lg-7 col-xl-6 offset-xl-1">
              <div
                class="testimonials-widget wow fadeInRight"
                data-wow-delay=".5s"
              >
                <div class="owl-carousel testimonial-carousel">
                  <div class="testimonial-item">
                    <div
                      class="top-area d-flex flex-wrap justify-content-between"
                    >
                      <div class="logo-box">
                        <img src="assets/img/testimonials/logo/1.png" alt="" />
                      </div>
                      <div class="image-box">
                        <img src="assets/img/testimonials/user/1.jpg" alt="" />
                      </div>
                    </div>
                    <div class="icon-box">
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_588)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_588"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_589)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_589"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                    <p class="quote">
                      “Taylor is a professional Designer he really helps my
                      business by providing value to my business.
                    </p>
                    <h4 class="name">Brandon Fraser</h4>
                    <span class="designation"
                      >Senior Software Dev, Cosmic Sport</span
                    >
                  </div>
                  <div class="testimonial-item">
                    <div
                      class="top-area d-flex flex-wrap justify-content-between"
                    >
                      <div class="logo-box">
                        <img src="assets/img/testimonials/logo/2.png" alt="" />
                      </div>
                      <div class="image-box">
                        <img src="assets/img/testimonials/user/2.jpg" alt="" />
                      </div>
                    </div>
                    <div class="icon-box">
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_511)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_511"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_510)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_510"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                    <p class="quote">
                      “Taylor is a professional Designer he really helps my
                      business by providing value to my business.
                    </p>
                    <h4 class="name">Tim Bailey</h4>
                    <span class="designation"
                      >SEO Specialist, Theme Junction</span
                    >
                  </div>
                  <div class="testimonial-item">
                    <div
                      class="top-area d-flex flex-wrap justify-content-between"
                    >
                      <div class="logo-box">
                        <img src="assets/img/testimonials/logo/1.png" alt="" />
                      </div>
                      <div class="image-box">
                        <img src="assets/img/testimonials/user/1.jpg" alt="" />
                      </div>
                    </div>
                    <div class="icon-box">
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_512)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_512"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_513)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_513"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                    <p class="quote">
                      “Taylor is a professional Designer he really helps my
                      business by providing value to my business.
                    </p>
                    <h4 class="name">Brandon Fraser</h4>
                    <span class="designation"
                      >Senior Software Dev, Cosmic Sport</span
                    >
                  </div>
                  <div class="testimonial-item">
                    <div
                      class="top-area d-flex flex-wrap justify-content-between"
                    >
                      <div class="logo-box">
                        <img src="assets/img/testimonials/logo/2.png" alt="" />
                      </div>
                      <div class="image-box">
                        <img src="assets/img/testimonials/user/2.jpg" alt="" />
                      </div>
                    </div>
                    <div class="icon-box">
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_514)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_514"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 22 22"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M0.105431 2.18998C0.0301532 0.988687 1.02531 -0.00647222 2.2266 0.0688056L19.4961 1.15097C21.2148 1.25867 22.0029 3.34358 20.7852 4.56127L4.5979 20.7486C3.3802 21.9663 1.2953 21.1781 1.1876 19.4594L0.105431 2.18998Z"
                          fill="url(#paint0_linear_263_515)"
                        />
                        <defs>
                          <linearGradient
                            id="paint0_linear_263_515"
                            x1="-0.0363755"
                            y1="-0.0729998"
                            x2="35.3333"
                            y2="-0.0729991"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop
                              offset="1"
                              stop-color="var(--tj-theme-primary)"
                            />
                            <stop
                              offset="1"
                              stop-color="#140C1C"
                              stop-opacity="0"
                            />
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                    <p class="quote">
                      “Taylor is a professional Designer he really helps my
                      business by providing value to my business.
                    </p>
                    <h4 class="name">Tim Bailey</h4>
                    <span class="designation"
                      >SEO Specialist, Theme Junction</span
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- TESTIMONIAL SECTION END -->

      <!-- CONTACT SECTION START -->
      <section class="contact-section" id="contact-section">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-7 order-2 order-md-1">
              <div class="contact-form-box wow fadeInLeft" data-wow-delay=".3s">
                <div class="section-header">
                  <h2 class="section-title">Let’s work together!</h2>
                  <p>
                    I design and code beautifully simple things and i love what
                    i do. Just simple like that!
                  </p>
                </div>

                <div class="tj-contact-form">
                  <form action="contact_process.php" method="post">
                    <div class="row gx-3">
                      <div class="col-sm-6">
                        <div class="form_group">
                          <input
                            type="text"
                            name="fname"
                            id="fname"
                            placeholder="First name"
                            autocomplete="off"
                          />
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form_group">
                          <input
                            type="text"
                            name="lname"
                            id="lname"
                            placeholder="Last name"
                            autocomplete="off"
                          />
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form_group">
                          <input
                            type="email"
                            name="email"
                            id="email"
                            placeholder="Email address"
                            autocomplete="off"
                          />
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form_group">
                          <input
                            type="tel"
                            name="phone"
                            id="phone"
                            placeholder="Phone number"
                            autocomplete="off"
                          />
                        </div>
                      </div>

                      <div class="col-12">
                        <div class="form_group">
                          <textarea
                            name="message"
                            id="message"
                            placeholder="Message"
                          ></textarea>
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="form_btn">
                          <button type="submit" class="btn tj-btn-primary">
                            Send Message
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            <div
              class="col-lg-5 offset-lg-1 col-md-5 d-flex flex-wrap align-items-center order-1 order-md-2"
            >
              <div class="contact-info-list">
                <ul class="ul-reset">
                  <li
                    class="d-flex flex-wrap align-items-center position-relative wow fadeInRight"
                    data-wow-delay=".4s"
                  >
                    <div class="icon-box">
                      <i class="flaticon-phone-call"></i>
                    </div>
                    <div class="text-box">
                      <p>Phone</p>
                      <a href="tel:+92 3192613543">+92 3192613543</a>
                    </div>
                  </li>
                  <li
                    class="d-flex flex-wrap align-items-center position-relative wow fadeInRight"
                    data-wow-delay=".5s"
                  >
                    <div class="icon-box">
                      <i class="flaticon-mail-inbox-app"></i>
                    </div>
                    <div class="text-box">
                      <p>Email</p>
                      <a href="mailto:hk2592755@gmail.com"
                        >hk2592755@gmail.com</a
                      >
                    </div>
                  </li>
                  <li
                    class="d-flex flex-wrap align-items-center position-relative wow fadeInRight"
                    data-wow-delay=".6s"
                  >
                    <div class="icon-box">
                      <i class="flaticon-location"></i>
                    </div>
                    <div class="text-box">
                      <p>Address</p>
                      <a href="#">Karachi Pakistan<br /></a>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- CONTACT SECTION END -->
    </main>

    <a
      rel="noopener noreferrer"
      href="https://api.whatsapp.com/send?phone=+923192613543&amp;text=Thanks%21%20Your%20For%20Contact."
      class="float"
      target="_blank"
    >
      <i class="fab fa-whatsapp my-float"></i>
    </a>

    <!-- FOOTER AREA START -->
    <footer class="tj-footer-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <div class="footer-logo-box">
              <a href="#"><img src="assets/img/logo/logo.png" alt="" /></a>
            </div>
            <div class="footer-menu">
              <nav>
                <ul>
                  <li><a href="#services-section">Services</a></li>
                  <li><a href="#works-section">Works</a></li>
                  <li><a href="#resume-section">Resume</a></li>
                  <li><a href="#skills-section">Skills</a></li>
                  <li><a href="#testimonials-section">Testimonials</a></li>
                  <li><a href="#contact-section">Contact</a></li>
                </ul>
              </nav>
            </div>
            <div class="copy-text">
              <p>
                &copy; 2024 All rights reserved by
                <a href="#" target="_blank">Hussian Khan</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- FOOTER AREA END -->

    <!-- CSS here -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/nice-select.min.js"></script>
    <script src="assets/js/backToTop.js"></script>
    <script src="assets/js/smooth-scroll.js"></script>
    <script src="assets/js/appear.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/gsap.min.js"></script>
    <script src="assets/js/one-page-nav.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/odometer.min.js"></script>
    <script src="assets/js/magnific-popup.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <script src="assets/js/main.js"></script>
  </body>
</html>
