<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You</title>
</head>
<body>
    <h1>Thank you for contacting us!</h1>
    <p>We have received your message and will get back to you shortly.</p>
</body>
</html>