<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);
// Include PHPMailer files
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './vendor/phpmailer/phpmailer/src/Exception.php';
require './vendor/phpmailer/phpmailer/src/PHPMailer.php';
require './vendor/phpmailer/phpmailer/src/SMTP.php';

echo "Step 1: Beginning of file reached.<br>";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "Step 2: Form was submitted.<br>";
    // Collect form data
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    echo "Step 3: Data collected.<br>";

    // Your email and SMTP configuration
    $yourEmail = "hk2592755@gmail.com";
    $smtpHost = "smtp.gmail.com"; // SMTP server
    $smtpUser = "hk2592755@gmail.com"; // SMTP username
    $smtpPassword = "rqzo jnzh ovas ztqn"; // SMTP password
    $smtpPort = 587; // SMTP port (use 587 for TLS or 465 for SSL)

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = $smtpHost;
        $mail->SMTPAuth = true;
        $mail->Username = $smtpUser;
        $mail->Password = $smtpPassword;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = $smtpPort;

        // Email to yourself
        $mail->setFrom($email, $firstName . ' ' . $lastName);
        $mail->addAddress($yourEmail);
        $mail->Subject = "New Message from Portfolio Contact Form";
        $mail->Body = "Name: " . $firstName . " " . $lastName . "\nEmail: " . $email . "\nPhone: " . $phone . "\n\nMessage:\n" . $message;

        // Send email to yourself
        $mail->send();

        // Send confirmation email to client
        $mail->clearAddresses();
        $mail->addAddress($email);
        $mail->Subject = "Thank You for Contacting Us!";
        $mail->Body = "Hello " . $firstName . ",\n\nThank you for reaching out. We have received your message and will get back to you soon.";

        $mail->send();

        // Redirect to thank you page
        header("Location: ./");
        exit();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
